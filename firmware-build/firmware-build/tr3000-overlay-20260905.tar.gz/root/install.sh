﻿#!/bin/sh
#===========================================
# 校园网自动登录 — 一键部署脚本
# 用法: 在 OpenWrt 上运行
#   chmod +x install.sh && ./install.sh
#===========================================

set -e

SCRIPT_NAME="campus-login.sh"
INSTALL_DIR="/root"
SCRIPT_PATH="${INSTALL_DIR}/${SCRIPT_NAME}"
HOTPLUG_SRC="99-campus-login.hotplug"
HOTPLUG_DST="/etc/hotplug.d/iface/99-campus-login"
CRON_FILE="/etc/crontabs/root"
CRON_MARKER="# campus-login auto"

echo "============================================"
echo "  校园网断网自动登录 — 部署工具"
echo "============================================"

# 1. 安装主脚本
echo ""
echo "[1/4] Installing main script to $SCRIPT_PATH ..."
if [ -f "./${SCRIPT_NAME}" ]; then
    cp "./${SCRIPT_NAME}" "$SCRIPT_PATH"
elif [ -f "${SCRIPT_NAME}" ]; then
    cp "${SCRIPT_NAME}" "$SCRIPT_PATH"
else
    echo "ERROR: ${SCRIPT_NAME} not found in current directory!"
    exit 1
fi
chmod +x "$SCRIPT_PATH"
echo "  -> Done."

# 2. 安装 hotplug 热插拔脚本
echo ""
echo "[2/4] Installing hotplug trigger ..."
if [ -f "./${HOTPLUG_SRC}" ]; then
    cp "./${HOTPLUG_SRC}" "$HOTPLUG_DST"
elif [ -f "${HOTPLUG_SRC}" ]; then
    cp "${HOTPLUG_SRC}" "$HOTPLUG_DST"
else
    echo "  -> ${HOTPLUG_SRC} not found, skipping hotplug."
fi
[ -f "$HOTPLUG_DST" ] && chmod +x "$HOTPLUG_DST" && echo "  -> Done."

# 3. 配置 cron 定时兜底
echo ""
echo "[3/4] Setting up cron (every 5 min) ..."
if ! grep -q "$CRON_MARKER" "$CRON_FILE" 2>/dev/null; then
    echo "*/5 * * * * ${SCRIPT_PATH} ${CRON_MARKER}" >> "$CRON_FILE"
    /etc/init.d/cron restart 2>/dev/null || service cron restart 2>/dev/null || true
    echo "  -> Done."
else
    echo "  -> Cron already configured, skip."
fi

# 4. 启动 daemon
echo ""
echo "[4/4] Starting daemon ..."
if [ -f "/var/run/campus-login.pid" ]; then
    "$SCRIPT_PATH" --stop 2>/dev/null || true
    sleep 1
fi
"$SCRIPT_PATH" --daemon &
sleep 2
if [ -f "/var/run/campus-login.pid" ] && kill -0 "$(cat /var/run/campus-login.pid)" 2>/dev/null; then
    echo "  -> Daemon started OK!"
else
    echo "  -> WARNING: Daemon may not have started. Check logs with: logread | grep campus"
fi

# 开机自启
echo ""
echo "=== Adding to rc.local for boot auto-start ==="
if ! grep -q "$SCRIPT_PATH" /etc/rc.local 2>/dev/null; then
    sed -i "/^exit 0/i ${SCRIPT_PATH} --daemon &" /etc/rc.local 2>/dev/null || \
    echo "${SCRIPT_PATH} --daemon &" >> /etc/rc.local
    echo "  -> Done."
else
    echo "  -> Already in rc.local, skip."
fi

echo ""
echo "============================================"
echo "  部署完成！实时日志查看:"
echo "    logread -f | grep campus"
echo ""
echo "  手动命令:"
echo "    ${SCRIPT_PATH}           一键检测+登录"
echo "    ${SCRIPT_PATH} --daemon  启动后台监听"
echo "    ${SCRIPT_PATH} --stop    停止后台监听"
echo "    ${SCRIPT_PATH} --status  查看运行状态"
echo "============================================"
